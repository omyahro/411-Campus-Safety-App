// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'serializers.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializers _$serializers = (new Serializers().toBuilder()
      ..add(JournalsRecord.serializer)
      ..add(UsersRecord.serializer)
      ..add(UsersStruct.serializer))
    .build();

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
